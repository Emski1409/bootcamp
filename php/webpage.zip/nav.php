

      <div id = "nav">
        <h3><a href="page1.html">menu item 1</a></h3>
        <h3><a href="page2.html">menu item 2</a></h3>
      </div>

     