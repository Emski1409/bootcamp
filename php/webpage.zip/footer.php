<!DOCTYPE html>
<html>
  <head>
    <title> Hello World</title>
    
    
    <link rel = "stylesheet" type = "text/css" href = "a.css" />

  </head>
      <body>
       
      <div id = "footer">
      <p> Contact me at eterry@alactrityfoundation.com</p>
      </div>
       

      </body>


<html>